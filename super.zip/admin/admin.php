<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Panel Administrativo</title>
    <link rel="stylesheet" href="estiloadmin/admin.css">
  </head>
  <body>
  <ul>
      <li class="dropdown">
          <a class="dropbtn" href="">Productos</a>
          <div class="dropdown-content">
              <a href="">Gestionar ofertas</a>
              <a href="">Productos en almacen</a>
          </div>
      </li>
      <li class="dropdown">
          <a class="dropbtn" href="">Empleados</a>
          <div class="dropdown-content">
              <a href="regempleado.php">Registro del personal</a>
              <a href="">Informacion del personal</a>
          </div>
      </li>
      <li class="dropdown">
          <a class="dropbtn" href="">Suministro</a>
          <div class="dropdown-content">
              <a href="">Gestionar proveedor</a>
              <a href="">Pedir suministro</a>
              <a href="">Recibir suministro</a>
          </div>
      </li>
      <li class="dropdown">
          <a class="dropbtn" href="">Encuestas</a>
          <div class="dropdown-content">
              <a href="">Ver encuestas</a>
              <a href="">Gestionar encuestas</a>
          </div>
      </li>
  </ul>

  <a href="../plantilla/listaempleados.php" target="_blank"><input type="submit" value="Ver Reporte"></a>
    <div class="divtabla">
    <table class="tabla">
        <tr>
            <th>nombre</th>
            <th>precio</th>
            <th>cantidad</th>
            <th>compañia</th>
            <th></th>
        </tr>
      <?php
      session_start();
      include "../sql.php";
        $sql = sprintf("select productos.fullnombre,productos.precio,productos.cantidad,compania.nombre from productos,compania");
        $resul = $coneccion->query($sql) or die(" sql de admin.php linea 26 mal dicha");
        while($fila = $resul->fetch_array()){
            echo "<tr>";
                echo '<td>'.$fila["fullnombre"].'</td>';
                echo '<td>'.$fila["precio"].'</td>';
                echo '<td>'.$fila["cantidad"].'</td>';
                echo '<td>'.$fila["nombre"].'</td>';
                echo '<td><a href="#"><input type="submit" value="dar de baja"></a></td>';
            echo"</tr>";
        }
       ?>
    </table>
    </div>
  </body>
</html>
