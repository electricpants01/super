<?php
 if(! $_POST) {
     ?>
     <!DOCTYPE html>
     <html lang="en" dir="ltr">
     <head>
         <meta charset="utf-8">
         <title>barra2</title>
         <link rel="stylesheet" href="estiloadmin/admin.css">
     </head>
     <body>
     <ul>
         <li class="dropdown">
             <a class="dropbtn" href="">Productos</a>
             <div class="dropdown-content">
                 <a href="">Gestionar ofertas</a>
                 <a href="">Productos en almacen</a>
             </div>
         </li>
         <li class="dropdown">
             <a class="dropbtn" href="">Empleados</a>
             <div class="dropdown-content">
                 <a href="">Registro del personal</a>
                 <a href="">Informacion del personal</a>
             </div>
         </li>
         <li class="dropdown">
             <a class="dropbtn" href="">Suministro</a>
             <div class="dropdown-content">
                 <a href="">Gestionar proveedor</a>
                 <a href="">Pedir suministro</a>
                 <a href="">Recibir suministro</a>
             </div>
         </li>
         <li class="dropdown">
             <a class="dropbtn" href="">Encuestas</a>
             <div class="dropdown-content">
                 <a href="">Ver encuestas</a>
                 <a href="">Gestionar encuestas</a>
             </div>
         </li>
     </ul>
     <div class="container">
         <form action="" method="post">
             <p>Registro del personal</p>
             <div class="row">
                 <div class="col-25">
                     <label for="">Nombre :</label>
                 </div>
                 <div class="col-75">
                     <input type="text" name="nombre" value="">
                 </div>
             </div>
             <div class="row">
                 <div class="col-25">
                     <label for="">Apellidos : </label>
                 </div>
                 <div class="col-75">
                     <input type="text" name="apellido" value="">
                 </div>
             </div>
             <div class="row">
                 <div class="col-25">
                     <label for="">sexo :</label>
                 </div>
                 <div class="col-75">
                     <select  name="sexo[]">
                         <option value="hombre">hombre</option>
                         <option value="mujer">mujer</option>
                         <option value="ninguno">No binario</option>
                     </select>
                 </div>
             </div>
             <div class="row">
                 <div class="col-25">
                     <label for="">Fecha de nacimiento :</label>
                 </div>
                 <div class="col-75">
                     <input type="date" name="date">
                 </div>
             </div>
             <div class="row">
                 <div class="col-25">
                     <label for="">Carnet de Identidad :</label>
                 </div>
                 <div class="col-75">
                     <input type="text" name="ci" value="">
                 </div>
             </div>
             <div class="row">
                 <div class="col-25">
                     <label for="">Direccion :</label>
                 </div>
                 <div class="col-75">

                 </div>
             </div>
             <div class="row">
                 <div class="col-25">
                     <label for="">Correo :</label>
                 </div>
                 <div class="col-75">
                     <input type="text" name="correo" value="">
                 </div>
             </div>
             <div class="row">
                 <div class="col-25">
                     <label for="">Telefono :</label>
                 </div>
                 <div class="col-75">
                     <input type="text" name="telefono" value="">
                 </div>
             </div>
             <div class="row">
                 <div class="col-25">
                     <label for="">Sueldo :</label>
                 </div>
                 <div class="col-75">
                     <input type="number" name="sueldo" value="0" max="7000">
                 </div>
             </div>
             <div class="row">
                 <div class="col-25">
                     <label for="">Cargo :</label>
                 </div>
                 <div class="col-75">
                     <select class="" name="">
                     </select>
                 </div>
             </div>
             <div class="row">
                 <div class="col-25">
                     <label for="">Contraseña :</label>
                 </div>
                 <div class="col-75">
                     <input type="password" name="contra" value="">
                 </div>
             </div>
             <div class="row">
                 <div class="col-25">
                     <label for="">Repetir Contraseña :</label>
                 </div>
                 <div class="col-75">
                     <input type="password" name="" value="">
                 </div>
             </div>
             <div class="row">
                 <input type="submit" value="registrar">
             </div>
         </form>
     </div>
     </body>
     </html>
     <?php
 } else{
     // metodo post codigo
 }
 ?>


