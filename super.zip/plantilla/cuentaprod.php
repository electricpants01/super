<?php

session_start();
require_once('../lib/mpdf.php');
include '../sql.php';
$nuevo = new mPDF('C','A4');
$sql = sprintf("SELECT productos.fullnombre, ventas.cantidad,productos.descuento,productos.precio from productos,ventas where ventas.idusuario = '%s' and productos.id = ventas.idproducto",$_SESSION["id"]);
$resul = $coneccion->query($sql);
while($filas[] = $resul->fetch_array())
    $html = '<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Reporte Empleados</title>
    <link rel="stylesheet" href="style.css" media="all" />
  </head>
  <body>
    <header class="clearfix">
      <div id="logo">
        <img src="logo.jpg">
      </div>
      <h1>SUPERMERCADO BIENSURTIDO</h1>
      <div id="company" class="clearfix">
        <div>BIENSURTIDO</div>
        <div>SANTA CRUZ,<br /> BOLIVIA</div>
        <div>70873323</div>
        <div><a href="mailto:company@example.com">admin@biensurtido.com</a></div>
      </div>
      <div id="project">
        <div><span>PROJECT</span> SUPERMERCADO BIENSURTIDO</div>
        <div><span>CLIENT</span> CHRISTIAN TORRICO AVILA</div>
        <div><span>ADDRESS</span> CALLE MANUEL GUEMES 2DO ANILLO </div>
        <div><span>EMAIL</span> <a href="mailto:john@example.com">admin@biensurtido.com</a></div>
        <div><span>DATE</span>'.date('m/d/Y h:i:s a', time()).'</div>
        
      </div>
    </header>
    <main>
      <table>
        <thead>
          <tr>
            <th class="service">NOMBRE</th>
            <th>CANTIDAD</th>
            <th>DESCUENTO</th>
            <th class="desc">PRECIO</th>
          </tr>
        </thead>
        <tbody>';
foreach ($filas as $fila ){
    $html .= '<tr>
            <td>'.$fila["fullnombre"].'</td>
            <td>'.$fila["cantidad"].'</td>
            <td>'.$fila["descuento"].'</td>
            <td>'.$fila["precio"].'</td>
            </tr>';
}
$html .='</tbody>
      </table>
      
    </main>
    <footer>
      Creado por Christian Torrico Avila
    </footer>
  </body>
</html>';
$nuevo->WriteHTML($html);
$nuevo->Output('reporte.pdf','I');
?>