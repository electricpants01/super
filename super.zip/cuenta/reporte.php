<?php

session_start();
if($_SESSION["authenticated"]){ ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Biensurtido</title>
        <link rel="stylesheet" href="../estilos/index.css">
        <link rel="stylesheet" href="../estilos/fontawesome/all.css">
    </head>
    <body>
    <form action="s/search.php" method="GET">
        <div class="nav1">
            <a id="logo" href="index.php"><i class="fas fa-store">BienSurtido</i></a>
            <select>
                <option>CATEGORIA</option>
                <?php
                //session_start(); INICIO DE SESION YA REALIZADA EN "indexinicio.php"

                include "../sql.php"; // Incluimos la base de datos

                $sql = "select * from categoria";
                $resul = $coneccion->query($sql);
                if( $resul === false){
                    die("error en la consulta");
                }
                while( $fila = $resul->fetch_array()){
                    echo "<option>".$fila["nombre"]."</option>>";
                }
                ?>
            </select>
            <input type="text" name="search">
            <input type="submit" value="buscar">
            <a href="../carro.php" class="logocarro"><i class="fas fa-shopping-cart"></i></a>
        </div>
    </form>
    <div class="login">
        <div class="dropdown">
            <a href="login.html"><?php echo($_SESSION["nombre"]);?></a>
            <div class="dropdown-content">
                <a href="../cuenta.php">Cuenta</a><br>
                <a href="../cerrar.php">Cerrar sesion</a>
            </div>
        </div>
    </div>
    <div class="sidenav">
        <a href="../cuenta.php">Datos Personales</a>
        <a href="reporte.php">Reportes</a>
        <a href="#clients">Cambiar contraseña</a>
    </div>
    <?php
        include '../sql.php';
        $sql = sprintf("select count(*) as contar from ventas where idusuario = '%s'",$_SESSION["id"]);
        $re = $coneccion->query($sql);
        if( $re === false) die("erro en la linea 57 del reporte.php");
        // vamos a contar la cantidad de ventas que realizo el usuario
        $fila = $re->fetch_array();
        $cont = $fila["contar"];
        if($cont != 0){
            $sql = sprintf("select distinct day(fecha) as dia from ventas where idusuario = '%s'",$_SESSION["id"]);
            $resul = $coneccion->query($sql);
            if( $resul === false) die("error en la linea 57 de resporte.php");
            // obtenemso todos los array de las comprar por distintos dias del mes
            $fila = $resul->fetch_array();
            $dia = $fila["dia"];
            echo "<p class='preporte'>Ver reporte de la compra del dia ".$dia."/12 <input type='submit' value='Click Aqui'></p>";
        }
        else{
            echo "<p class='preporte'>No ha realizado ninguna compra</p>";
        }

    ?>

    </body>
    </html>
    <?php
}else{
    $host = $_SERVER["HTTP_HOST"];
    $uri = rtrim(dirname($_SERVER["PHP_SELF"]), "/\\");
    header("Location: http://$host$uri/login.html");
}

?>