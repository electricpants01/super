<?php


    session_start();
    include  '../sql.php';
    $nombre = $_POST["nombre"];
    $apellido = $_POST["apellido"];
    $correo = $_POST["correo"];
    $direccion = $_POST["direccion"];
    $sql = sprintf("update usuario set nombre = '%s',apellidos='%s',correo = '%s', direccion = '%s' where id  = '%s'",
        $nombre,$apellido,$correo,$direccion,$_SESSION["id"]);
    $resul = $coneccion->query($sql);
    if( $resul === false) die("error en la consulta linea 13 archivo actualizar.php");

?>

<script>
    window.location = "../index.php";
</script>
