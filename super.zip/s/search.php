<?php
//FUNCIONES DE BUSQUEDA
function busqueda1($word){
    //busqueda por idcompania
    include "../sql.php"; // REVISAR DE AQUI PA ABAJO
    $sql = sprintf("select * from productos where idcompania = (select idcompania from compania where nombre = '%s')",$word);
    $resul = $coneccion->query($sql);
    if( $resul === false){
        die("indexinicio.php consulta sql de productos error");
    }
    echo"<table class='tablesql'>";
    while( $fila = $resul->fetch_array()){
        echo"<tr>";
        echo"<td>";
        echo $fila["fullnombre"]."</br>";
        echo "<img src='../photos/".$fila["imagen"]."' width='500' height='300'> </br>";
        echo $fila["precio"]."</br>";
        echo"<button>Comprar ahora</button>";
        echo"</td>";
        echo"</tr>";
    }
}
function busqueda2($word){
    //busqueda por nombreprod
    include "../sql.php"; // REVISAR DE AQUI PA ABAJO
    $sql = sprintf("select * from productos where idnombreprod = (select id from nombreprod where nombre = '%s')",$word);
    $resul = $coneccion->query($sql);
    if( $resul === false){
        die("indexinicio.php consulta sql de productos error");
    }
    echo"<table class='tablesql'>";
    while( $fila = $resul->fetch_array()){
        echo"<tr>";
        echo"<td>";
        echo $fila["fullnombre"]."</br>";
        echo "<img src='../photos/".$fila["imagen"]."' width='500' height='300'> </br>";
        echo $fila["precio"]."</br>";
        echo"<button>Comprar ahora</button>";
        echo"</td>";
        echo"</tr>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Biensurtido</title>
    <link rel="stylesheet" href="../estilos/index.css">
    <link rel="stylesheet" href="../estilos/fontawesome/all.css">
</head>
<body>
<form action="search.php" method="GET">
    <div class="nav1">
        <a id="logo" href="../index.php"><i class="fas fa-store">BienSurtido</i></a>
        <select>
            <option>CATEGORIA</option>
            <?php
            //session_start(); //INICIO DE SESION YA mas abajo

            include "../sql.php"; // Incluimos la base de datos

            $sql = "select * from categoria";
            $resul = $coneccion->query($sql);
            if( $resul === false){
                die("error en la consulta");
            }
            while( $fila = $resul->fetch_array()){
                echo "<option>".$fila["nombre"]."</option>>";
            }
            ?>
        </select>
        <input type="text" name="search">
        <input type="submit" value="buscar">
        <a href="carro.php" class="logocarro"><i class="fas fa-shopping-cart"></i></a>
    </div>
</form>
 <!--Aqui empieza la busqueda -->
<?php
session_start();
$word = $_GET["search"];
   if( isset($_SESSION["authenticated"])){
    if ($_SESSION["authenticated"] === true ){
        ?>
        <!--Contenido de nav de usuario -->
        <div class="login">
            <div class="dropdown">
                <a href=""><?php echo($_SESSION["nombre"]);?></a>
                <div class="dropdown-content">
                    <a href="../cuenta.php">Cuenta</a><br>
                    <a href="../cerrar.php">Cerrar sesion</a>
                </div>
            </div>
        </div>
        <!--Contenido de Productos -->
        <?php
        busqueda1($word);
        echo"</table>";
         }}else{
        ?>
         <div class="login">
        <div class="dropdown">
            <a href="../login.html">Ingresar</a>
            <div class="dropdown-content">
                <a href="../login.html">Login</a><br>
                <a href="../registro.html">Registrate</a>
            </div>
        </div>
    </div>
    <?php
       $sql = sprintf("select * from productos where idcompania = (select id from compania where nombre = '%s')",$word);
       //coneccion incluida mas arriba, asi que no hay necesidad de volverla a incluir
       $resul = $coneccion->query($sql);
       if($resul === false){
           die("consulta de la linea 115 mal hecha");
           exit;
       }
       if( $resul->num_rows > 0){
           busqueda1($word);
           echo "</table>";
       }
       $sql = sprintf("select * from productos where idnombreprod = (select id from nombreprod where nombre = '%s' limit 1)",$word);
       $resul = $coneccion->query($sql);
       if( $resul === false){
           die("consulta sql de la linea 125 mal hecha");
       }
       if( $resul->num_rows > 0){
           busqueda2($word);
           echo "</table>";
       }else{
           echo "<div class='no-existe-prod'>";
                echo "<h1>NO EXISTE EL PRODUCTO</h1>";
                echo "<h2>Pero puede sugerirlo</h2>";
                echo "<form action=''>";
                    echo "Nombre de su producto <input type='text' placeholder='Nombre del producto' name='producto'>";
                echo "</form>";
                echo "<input type='submit' value='Continuar'>";
           echo "</div>";
       }
}
?>
</body>
</html>