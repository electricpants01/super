﻿ drop database supermarket;
 create database supermarket;

 use supermarket;

-- Clase Horario
-- drop table Horario;
create table Horario(
	Id int not null primary key,
);
-- Clase Periodos
-- drop table Periodos;
create table Periodo(
	Id int not null primary key,
	Dia varchar(2) not null,
	H_Ingreso time not null,
	H_Salida time not null
);

-- Clase Conforma
-- drop table Conforma;
create table Conforma(
	Id_Horario int not null,
	Id_Periodo int not null,
	primary key(Id_Horario,Id_Periodo),
	foreign key (Id_Horario) references Horario(Id)
	on delete cascade
	on update cascade,
	foreign key (Id_Periodo) references Periodo(Id)
	on delete cascade
	on update cascade
);

-- Clase Persona
-- Drop table Persona;
create table Persona(
	CI int not null primary key,
	Nombre varchar(50) not null,
	Apellido varchar(50) not null,
	Sexo char not null,
	Fecha_Nacimiento date not null,
	Direccion varchar(60),
	Correo varchar(40) not null,
	Telefono int,
	Tipo_P tinyint not null,	
	Tipo_U tinyint not null
);

-- Clase Personal
-- drop table Personal;
create table Personal(
	Id int not null,
	CI_Persona int not null,
	Sueldo float not null,
	Clave varchar(30) not null,
	Id_Horario int,
	primary key(Id, CI_Persona),
	foreign key(CI_Persona) references Persona(CI)
	on delete cascade
	on update cascade,
	foreign key(Id_Horario) references Horario(Id)
	on delete cascade
	on update cascade
);


-- Clase Usuario
-- drop table Usuario;
create table Usuario(
	Id int not null,
	CI_Persona int not null,
	Nombre_Usuario varchar(25) not null,
	Clave varchar(30) not null,
	primary key(Id,CI_Persona),
	foreign key (CI_Persona) references Persona(CI)
	on delete cascade
	on update cascade
);

-- Clase Asistencia
-- drop table Asistencia;
create table Asistencia(
	Id int not null primary key,
	Fecha date not null
);

-- Clase Registra
-- drop table Registra;
create table Registra(
	Id_Personal int not null,
	CI_Persona int not null,
	Id_Asistencia int not null,
	Hora_Ingreso time(0) not null,
	Hora_Salida time(0) not null,
	Tipo char not null,	--I ingreso S salida
	primary key(Id_Personal,CI_Persona,Id_Asistencia),
	foreign key (Id_Asistencia) references Asistencia(Id)
	on update cascade
	on delete cascade,
	foreign key (ID_Personal,CI_Persona) references Personal(Id,CI_Persona)
	on update cascade
	on delete no action		
);

-- Clase Origen
-- drop table Origen;
create table Origen(
	Id int not null primary key,
	Nombre varchar(25) not null
);

-- Clase Formacion
-- drop table Formacion;
create table Formacion(
	Id int not null primary key,
	Nombre varchar(50) not null,
	Descripcion varchar(70),
	Id_Origen int,
	foreign key (Id_Origen) references Origen(Id)
	on delete cascade 
	on update cascade
);

-- Clase Posee
-- drop table Posee;
create table Posee(
	Id_Personal int not null,
	CI_Persona int not null,
	Id_Formacion int not null,
	primary key(Id_Personal,CI_Persona,Id_Formacion),
	foreign key (Id_Personal,CI_Persona) references Personal(Id,CI_Persona)
	on delete cascade
	on update cascade,
	foreign key (Id_Formacion) references Formacion(Id)
	on delete cascade
	on update cascade
);

-- Clase Cargo
-- drop table Cargo;
create table Cargo(
	Id int not null primary key,
	Nombre varchar(40) not null
);

-- Clase Tiene
-- drop table Tiene;
create table Tiene(
	Id_Personal int not null,
	CI_Persona int not null,
	Id_Cargo int not null,
	primary key(Id_Personal,CI_Persona,Id_Cargo),
	foreign key (Id_Personal,CI_Persona) references Personal(Id,CI_Persona)
	on delete cascade
	on update cascade,
	foreign key (Id_Cargo) references Cargo(Id)
	on delete cascade
	on update cascade
);

-- Clase Funcion
-- drop table Funcion;
create table Funcion(
	Id int not null primary key,
	Nombre varchar(35) not null,
	Descripcion varchar(50) not null
);

-- Clase Compone
-- drop table Compone;
create table Compone(
	Id_Cargo int not null,
	Id_Funcion int not null,
	primary key(Id_Cargo,Id_Funcion),
	foreign key(Id_Cargo) references Cargo(Id)
	on delete cascade 
	on update cascade,
	foreign key(Id_Funcion) references Funcion(Id)
	on delete cascade
	on update cascade
);

-- Clase Repartidor
-- drop table Repartidor;
create table Repartidor(
	Id int not null primary key,
	Estado tinyint not null,
	Id_Personal int not null,
	CI_Persona int not null,
	foreign key (Id_Personal,CI_Persona) references Personal(Id,CI_Persona)
	on delete cascade
	on update cascade
);

-- Clase Tipo_Pago
-- drop table Tipo_Pago;
create table Tipo_Pago(
	Id int not null primary key,
	Tipo varchar(20) not null
);

-- Clase Cliente
-- drop table Cliente;
create table Cliente(
	NIT int not null primary key,
	Nombre varchar(60) not null,
	Apellido varchar(50)
);

-- Clase Factura
-- drop table Factura;
create table Factura(
	Id int not null primary key,
	Fecha_Emision datetime not null,
	NIT_Cliente int not null,
	foreign key(NIT_Cliente) references Cliente(NIT)
	on delete no action
	on update no action
);

-- Clase NIT_Usuario
-- drop table NIT_Usuario;
create table NIT_Usuario(
	NIT int not null primary key,
	Nombre varchar(60) not null,
	Apellido varchar(50),
	Id_Usuario int not null,
	CI_Persona int not null,
	foreign key(Id_Usuario,CI_Persona) references Usuario(Id,CI_Persona)
	on delete cascade
	on update cascade
);

-- Clase Ubicacion
-- drop table Ubicacion;
create table Ubicacion(
	Id int not null primary key,
	Nombre varchar(30) not null,
	ID_Pertenece int
);

-- Clase Tipo
-- drop table Tipo;
create table Tipo(
	Id int not null primary key,
	Nombre varchar(30)
);
					
-- Clase Producto
-- drop table Producto;
create table Producto(
	Id int not null primary key,
	Nombre varchar(50) not null,
	Marca varchar(50) not null,
	Dias_Aviso int,
	Precio_Venta float not null,
	Por_Peso char not null, --"S" o "N"
	Total float not null
);

-- Clase Pertenece
-- drop table Pertenece;
create table Pertenece(
	Id_Producto int not null,
	Id_Tipo int not null,
	primary key(Id_Producto, Id_Tipo),
	foreign key(Id_Producto) references Producto(Id)
	on delete cascade
	on update cascade,
	foreign key(Id_Tipo) references Tipo(Id)
	on delete cascade
	on update cascade
);

-- Clase Carrito
-- drop table Carrito;
create table Carrito(
	Id int not null primary key,
	Nombre varchar(50) not null,
	Id_Usuario int not null,
	CI_Persona int not null,
	foreign key(Id_Usuario, CI_Persona) references Usuario(Id, CI_Persona)
	on delete cascade
	on update cascade
);

-- Clase Selecciona
-- drop table Selecciona;
create table Selecciona(
	Id_Producto int not null,
	Id_Carrito int not null,
	Cantidad int not null,
	Peso float,
	primary key(Id_Producto,Id_Carrito),
	foreign key(Id_Producto) references Producto(Id)
	on delete cascade
	on update cascade,
	foreign key(Id_Carrito) references Carrito(Id)
	on delete cascade
	on update cascade
);

-- Clase Proveedor
-- drop table Proveedor;
create table Proveedor(
	Id int not null primary key,
	Nombre varchar(50) not null,
	Direccion varchar(60) not null,
	Descripcion varchar(70) not null,
	Telefono int not null
);

-- Clase Suministro
-- drop table Suministro;
create table Suministro(
	Id int not null,
	Id_Producto int not null,
	Id_Proveedor int not null,
	Cantidad int not null,
	Peso float,
	Precio_Compra float not null,
	Fecha_Suministro datetime not null,
	Estado char not null,	--P pendiente, R revisado
	primary key(Id,Id_Producto,Id_Proveedor),
	foreign key(Id_Producto) references Producto(Id)
	on delete no action
	on update cascade,
	foreign key(Id_Proveedor) references Proveedor(Id)
	on delete no action 
	on update cascade
);

-- Clase Oferta
-- drop table Oferta;
create table Oferta(
	Id int not null primary key,
	Descripcion varchar(70) not null,
	Fecha_Inicio date not null,
	Fecha_Fin date not null,
	Porcentaje float not null
);

-- Clase Descuento
-- drop table Descuento;
	create table Descuento(
		Id_Producto int not null,
		Id_Oferta int not null,
		Cantidad int not null,
		Peso float,
		primary key(Id_Producto,Id_Oferta),
		foreign key(Id_Producto) references Producto(Id)
		on delete no action
		on update cascade,
		foreign key(Id_Oferta) references Oferta(Id)
		on delete cascade
		on update cascade
	);

-- Clase Catalogo
-- drop table Catalogo;
create table Catalogo(
	Id int not null primary key,
	Nombre varchar(30) not null,
	Descripcion varchar(70) not null,
	Estado tinyint not null,
);

-- Clase Seccion
-- drop table Seccion;
create table Seccion(
	Id_Catalogo int not null,
	Id int not null,
	Nombre varchar(40) not null,
	primary key(Id_Catalogo,Id),
	foreign key(Id_Catalogo) references Catalogo(Id)
	on delete cascade
	on update cascade
);

-- Clase Contiene
-- drop table Contiene;
create table Contiene(
	Id_Catalogo int not null,
	Id_Seccion int not null,
	Id_Producto int not null,
	primary key(Id_Catalogo,Id_Seccion,Id_Producto),
	foreign key(Id_Producto) references Producto(Id)
	on delete cascade
	on update cascade,
	foreign key(Id_Catalogo,Id_Seccion) references Seccion(Id_Catalogo,Id)
	on delete cascade
	on update cascade
);

-- Clase Existe
-- drop table Existe;
create table Existe(
	Id int not null primary key,
	Id_Producto int not null,
	Id_Ubicacion int not null,
	Cantidad int not null,
	Peso float,
	Fecha_Vencimiento date not null,
	foreign key(Id_Ubicacion) references Ubicacion(Id)
	on delete no action
	on update cascade,
	foreign key(Id_Producto) references Producto(Id)
	on delete no action 
	on update cascade
);
	

-- Clase Pedido
-- drop table Pedido;
create table Pedido(
	Id int not null primary key,
	Hora_Envio time(0),
	Hora_Llegada time(0),
	Direccion varchar(60) not null,
	Precio float not null,
	Prod_Reservado tinyint not null,
	Confirmado tinyint not null,
	Id_Usuario int not null,
	CI_Persona int not null,
	Id_Factura int,
	Id_Repartidor int not null,
	Id_Tipo_Pago int not null,
	Id_Carrito int,
	foreign key(Id_Usuario,CI_Persona) references Usuario(Id,CI_Persona)
	on delete no action
	on update cascade,
	foreign key(Id_Factura) references Factura(Id)
	on delete no action 
	on update cascade,
	foreign key(Id_Repartidor) references Repartidor(Id)
	on delete no action
	on update no action,
	foreign key(Id_Tipo_Pago) references Tipo_Pago(Id)
	on delete no action
	on update cascade,
	foreign key(Id_Carrito) references Carrito(Id)
	on delete set null
	on update no action
);

-- Clase Detalle_Venta
-- drop table Detalle_Venta
create table Detalle_Venta(
	Id_Factura int not null,
	Id int not null,
	Cantidad int not null,
	Precio float not null,
	Id_Existe int,
	Id_Pedido int,
	primary key(Id_Factura,Id),
	foreign key(Id_Factura) references Factura(Id)
	on delete cascade
	on update cascade,
	foreign key (Id_Existe) references Existe(Id)
	on delete no action
	on update cascade,
	foreign key (Id_Pedido) references Pedido(Id)
	on delete no action
	on update no action
);

-- Clase Reposicion
-- drop table Reposicion;
create table Reposicion(
	Id int not null primary key,
	Fecha_Reposicion datetime not null,
	Cantidad int not null,
	Precio_Unitario float not null,
	Estado char not null, --E en espera, R recibido, F finalizadoo
	Id_Proveedor int not null,
	Id_Existe int not null,
	foreign key(Id_Proveedor) references Proveedor(Id)
	on delete no action
	on update cascade,
	foreign key (Id_Existe) references Existe(Id)
	on delete no action
	on update cascade
);
-- Clase Encuesta
-- drop table Encuesta;
create table Encuesta(
	Id int not null primary key,
	Nombre varchar(30),
	CI_Persona int,
	Estado tinyint,
	Id_Usuario int,
	Id_Personal int,
	foreign key(Id_Usuario, CI_Persona) references Usuario(Id,CI_Persona)
	on delete no action
	on update no action,
	foreign key(Id_Personal, CI_Persona) references Personal(Id,CI_Persona)
	on delete no action
	on update no action
);

-- Clase Elemento
-- drop table Elemento;
create table Elemento(
	Id_Encuesta int not null,
	Id int not null,
	Pregunta varchar(75) not null,
	Producto varchar(50),
	Id_Producto int,
	Otras tinyint not null,	--0 no, 1 si permite otras respuestas
	primary key(Id_Encuesta, Id),
	foreign key(Id_Encuesta) references Encuesta(Id)
	on delete no action
	on update no action,
	foreign key(Id_Producto) references Producto(Id)
	on delete no action
	on update cascade
);
-- Clase Respuesta
-- drop table Respuesta;
create table Respuesta(
	Id_Encuesta int not null,
	Id_Elemento int not null,
	Id int not null,
	Nombre varchar(75) not null,
	Conteo int not null,
	primary key(Id_Encuesta,Id_Elemento, Id),
	foreign key(Id_Encuesta,Id_Elemento) references Elemento(Id_Encuesta,Id)
	on delete no action
	on update no action
);

-- Clase Otro
-- drop table Otro;
create table Otro(
	Id int not null primary key,
	Nombre varchar(75) not null,
	Conteo int not null,
	Id_Encuesta int not null,
	Id_Elemento int not null,
	foreign key(Id_Encuesta,Id_Elemento) references Elemento(Id_Encuesta,Id)
	on delete no action
	on update no action
);

-- Clase Encuesta_Usuario
-- drop table Encuesta_Usuario;
create table Encuesta_Usuario(
	Id_Encuesta int not null,
	Id_Usuario int not null,
	CI_Persona int not null,
	primary key(Id_Encuesta, Id_Usuario, CI_Persona),
	foreign key(Id_Usuario, CI_Persona) references Usuario(Id,CI_Persona)
	on delete no action
	on update no action,
	foreign key(Id_Encuesta) references Encuesta(Id)
	on delete no action
	on update no action
);

Alter table Ubicacion add 
	foreign key(Id_Pertenece) references Ubicacion(Id)
	on delete no action
	on update no action;

-- Clase Bitácora
-- drop table Bitácora;
create table Bitacora(
	Id int not null primary key,
	Modificado datetime not null,
	Operacion varchar(6) not null,
	Tabla varchar(20) not null,
	Usuario varchar(25) not null,
	Host varchar(15) not null
);

-- Clase Detalle_Bitácora
-- drop table Detalle_Bitácora;
create table Bitacora_Detalle(
    Id_Bitacora int not null,
    Id_Det int not null,
    Id_TabModif varchar(20) not null,
    Campo_Alterado char (50) not null,
    Valor_Anterior char (150) null,
    Valor_Nuevo char (150) null,
    primary key(Id_Bitacora,Id_Det,Id_TabModif),
    foreign key(Id_Bitacora) references Bitacora(Id)
    on delete no action
    on update no action
);


/*
drop table Persona;
drop table Personal;
drop table Usuario;
drop table Asistencia;
drop table Registra;
drop table Origen;
drop table Formacion;
drop table Posee;
drop table Cargo;

drop table Tiene;
drop table Funcion;
drop table Compone;
drop table Repartidor;
drop table Tipo_Pago;
drop table Cliente;
drop table Factura;
drop table NIT;

drop table Ubicacion;
drop table Tipo;
drop table Producto;
drop table Pertenece;
drop table Carrito;
drop table Selecciona;
drop table Proveedor;
drop table Suministro;

drop table Oferta;
drop table Descuento;
drop table Catalogo;
drop table Seccion;
drop table Contiene;
drop table Existe;
drop table Detalle_Venta;
drop table Pedido;

drop table Reposicion;
drop table Encuesta;
drop table Elemento;
drop table Respuesta;
drop table Otro;
drop table Encuesta_Usuario;
drop table Bitacora;
drop table Bitacora_Detalle;
--41 Clases
*/

