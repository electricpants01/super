
create database supermarket
use supermarket

create table usuario (
	id int identity primary key not null,
	nombre char(32) not null,
	apellidos varchar(64) not null,
	correo char(128) not null,
	contra char(60) not null, -- por que se encripta usa 6 de longitud
	direccion char(256),
	telefono int
);
create table nombreProd(
	id int identity primary key not null,
	nombre char(32) not null
);
create table categoria(
	id int identity primary key not null,
	nombre char(32) not null
);
create table compania(
	id int identity primary key not null,
	nombre char(32) not null
);

create table productos(
	id int identity primary key not null,
	fullnombre char(64) not null,
	precio decimal(10,2) not null,
	cantidad int not null,
	idnombreprod int not null,
	idcategoria int not null,
	idcompania int not null,
	imagen char(128) not null,
	foreign key (idcategoria) references categoria(id)
	on delete cascade
	on update cascade,
	foreign key (idcompania) references compania(id)
	on delete cascade
	on update cascade,
	foreign key (idnombreprod) references nombreProd(id)
	on delete cascade
	on update cascade
);


--poblar la cateogria
insert into categoria (nombre) values('alimentos refrigerantes');
insert into categoria (nombre) values('bebidas');
insert into categoria (nombre) values('congelados');
insert into categoria (nombre) values('frutas y verduras');
insert into categoria (nombre) values('carnes');
insert into categoria (nombre) values('aseo');

-- insertar nombreProd
insert into nombreProd (nombre) values ('leche');
insert into nombreProd (nombre) values ('refrigerado');
-- productos nuevos
insert into nombreProd (nombre) values ('cola cola');
insert into nombreProd (nombre) values ('agua');
insert into nombreProd (nombre) values ('coca cola zero');
insert into nombreProd (nombre) values ('dfrut');
insert into nombreProd (nombre) values ('fanta papaya');
insert into nombreProd (nombre) values ('tampico');
insert into nombreProd (nombre) values ('fanta');
insert into nombreProd (nombre) values ('pepsi');
insert into nombreProd (nombre) values ('gaseosa');
insert into nombreProd (nombre) values ('simba');
insert into nombreProd (nombre) values ('sprite');
insert into nombreProd (nombre) values ('refresco');
insert into nombreProd (nombre) values ('nectar de naranja');
insert into nombreProd (nombre) values ('nectar de molocoton');
insert into nombreProd (nombre) values ('nectar multifrutas');
insert into nombreProd (nombre) values ('nectar piña');
insert into nombreProd (nombre) values ('zumo naranja');
insert into nombreProd (nombre) values ('sidra');
insert into nombreProd (nombre) values ('vino blanco');
insert into nombreProd (nombre) values ('vino tinto');
insert into nombreProd (nombre) values ('vino claudius');
insert into nombreProd (nombre) values ('vino santa barbara');
insert into nombreProd (nombre) values ('carne res');
insert into nombreProd (nombre) values ('chorizo de pollo');
insert into nombreProd (nombre) values ('chorizo de res');
insert into nombreProd (nombre) values ('chorizo de cerdo');
insert into nombreProd (nombre) values ('carne cerdo');
insert into nombreProd (nombre) values ('carne molida');
insert into nombreProd (nombre) values ('huevos');
insert into nombreProd (nombre) values ('jamon de cerdo');
insert into nombreProd (nombre) values ('jamon de res');
insert into nombreProd (nombre) values ('jamon de pollo');
insert into nombreProd (nombre) values ('tocino');
insert into nombreProd (nombre) values ('chuleta');
insert into nombreProd (nombre) values ('pescado');
insert into nombreProd (nombre) values ('cordillera');
insert into nombreProd (nombre) values ('cerveza cruceña');
insert into nombreProd (nombre) values ('cerveza corona');
insert into nombreProd (nombre) values ('cerveza potosina');
insert into nombreProd (nombre) values ('cerveza ducal');
insert into nombreProd (nombre) values ('cerveza paceña');
insert into nombreProd (nombre) values ('cerveza huari');
insert into nombreProd (nombre) values ('cerveza real');
insert into nombreProd (nombre) values ('helado');
insert into nombreProd (nombre) values ('helado frutilla');
insert into nombreProd (nombre) values ('ajo');
insert into nombreProd (nombre) values ('banana');
insert into nombreProd (nombre) values ('cebolla');
insert into nombreProd (nombre) values ('apio');
insert into nombreProd (nombre) values ('arbejas');
insert into nombreProd (nombre) values ('brocoli');
insert into nombreProd (nombre) values ('papaya');
insert into nombreProd (nombre) values ('pera');
insert into nombreProd (nombre) values ('pimenton');
insert into nombreProd (nombre) values ('repollo');
insert into nombreProd (nombre) values ('tomate');
insert into nombreProd (nombre) values ('zapallo');
insert into nombreProd (nombre) values ('chuño');
insert into nombreProd (nombre) values ('choclo');
insert into nombreProd (nombre) values ('camote');
insert into nombreProd (nombre) values ('cerezas');
insert into nombreProd (nombre) values ('coco');
insert into nombreProd (nombre) values ('durazno');
insert into nombreProd (nombre) values ('frambuesa');
insert into nombreProd (nombre) values ('kiwi');
insert into nombreProd (nombre) values ('mango');
insert into nombreProd (nombre) values ('melon');
insert into nombreProd (nombre) values ('papaliza');
insert into nombreProd (nombre) values ('');
insert into nombreProd (nombre) values ('ciruelo');
insert into nombreProd (nombre) values ('frutilla');
insert into nombreProd (nombre) values ('lechuga');
insert into nombreProd (nombre) values ('limones');
insert into nombreProd (nombre) values ('manzana');
insert into nombreProd (nombre) values ('naranja');
insert into nombreProd (nombre) values ('nuez');
insert into nombreProd (nombre) values ('patatas');
insert into nombreProd (nombre) values ('pepino');
insert into nombreProd (nombre) values ('pimentones');
insert into nombreProd (nombre) values ('piña');
insert into nombreProd (nombre) values ('remolacha');
insert into nombreProd (nombre) values ('sandia');
insert into nombreProd (nombre) values ('uvas');
insert into nombreProd (nombre) values ('zanahorias');
insert into nombreProd (nombre) values ('refrigerado');
insert into nombreProd (nombre) values ('ace patito');
insert into nombreProd (nombre) values ('ace ariel');
insert into nombreProd (nombre) values ('ace bolivar');
insert into nombreProd (nombre) values ('ace bolivar limon');
insert into nombreProd (nombre) values ('ace bolivar de ropa delicada');
insert into nombreProd (nombre) values ('ace omo');
insert into nombreProd (nombre) values ('ace uno');
insert into nombreProd (nombre) values ('ace uno ropa delicada');
insert into nombreProd (nombre) values ('jabon bolivar perlas blancas');
insert into nombreProd (nombre) values ('jabon bolivar bebe');
insert into nombreProd (nombre) values ('jaboncillo dove');
insert into nombreProd (nombre) values ('javoncillo heno pravia');
insert into nombreProd (nombre) values ('javoncillo luxe');
insert into nombreProd (nombre) values ('jabon uno');
insert into nombreProd (nombre) values ('jabon uno antibacterial');
insert into nombreProd (nombre) values ('jabon uno glicerina');
insert into nombreProd (nombre) values ('jabon uno limon');
insert into nombreProd (nombre) values ('jabon uno ropa delicada');
insert into nombreProd (nombre) values ('lavavajilla ola');
insert into nombreProd (nombre) values ('shampoo head&shoulder');
insert into nombreProd (nombre) values ('shampoo head&shoulder manzana');
insert into nombreProd (nombre) values ('shampoo sedal control');
insert into nombreProd (nombre) values ('shampoo sedal liso');
insert into nombreProd (nombre) values ('shampoo sedal liso perfecto');
insert into nombreProd (nombre) values ('shampoo sedal');
insert into nombreProd (nombre) values ('lavavajilla');
insert into nombreProd (nombre) values ('lavavajilla a mano');
insert into nombreProd (nombre) values ('lavavajilla concentrado');
insert into nombreProd (nombre) values ('lavavajilla concentrado verde');
insert into nombreProd (nombre) values ('lavavajilla unico');
insert into nombreProd (nombre) values ('refrigerado');



-- poblar compania
insert into compania(nombre) values ('pil');
-- insertar 
--prblar los productoss
insert into productos (fullnombre,precio,cantidad,idnombreprod,idcategoria,idcompania,imagen) values('Leche sabor chocalatada',8.5,100,1,1,1,'12.jpg');
insert into productos (fullnombre,precio,cantidad,idnombreprod,idcategoria,idcompania,imagen) values('Pilfrut sabor frutilla',1.0,57,2,1,1,'1.jpg');
insert into productos (fullnombre,precio,cantidad,idnombreprod,idcategoria,idcompania,imagen) values('Pilfrut sabor manzana',1.0,200,2,1,1,'2.jpg');
insert into productos (fullnombre,precio,cantidad,idnombreprod,idcategoria,idcompania,imagen) values('Pilfrut sabor naranja',1.0,244,2,1,1,'3.jpg');
insert into productos (fullnombre,precio,cantidad,idnombreprod,idcategoria,idcompania,imagen) values('Leche semi descremada',8.0,158,1,1,1,'4.jpg');
insert into productos (fullnombre,precio,cantidad,idnombreprod,idcategoria,idcompania,imagen) values('Leche deslactosada',6.50,90,1,1,1,'5.jpg');
insert into productos (fullnombre,precio,cantidad,idnombreprod,idcategoria,idcompania,imagen) values('Leche deslactosada chocolatada',7.50,200,1,1,1,'7.jpg');
insert into productos (fullnombre,precio,cantidad,idnombreprod,idcategoria,idcompania,imagen) values('Leche deslactosada sabor frutilla',2.50,500,1,1,1,'8.jpg');
insert into productos (fullnombre,precio,cantidad,idnombreprod,idcategoria,idcompania,imagen) values('Leche deslactosada sabor chocolatada',2.5,79,1,1,1,'9.jpg');
insert into productos (fullnombre,precio,cantidad,idnombreprod,idcategoria,idcompania,imagen) values('Pilfrut sabor piña',1.0,245,2,1,1,'10.jpg');
insert into productos (fullnombre,precio,cantidad,idnombreprod,idcategoria,idcompania,imagen) values('Leche sabor frutilla',8.50,248,1,1,1,'11.jpg');
insert into productos (fullnombre,precio,cantidad,idnombreprod,idcategoria,idcompania,imagen) values('Leche con avena sabor canela',8.50,589,1,1,1,'13.jpg');
insert into productos (fullnombre,precio,cantidad,idnombreprod,idcategoria,idcompania,imagen) values('Leche blanca envase tetra brick',9.50,340,1,1,1,'14.jpg');
insert into productos (fullnombre,precio,cantidad,idnombreprod,idcategoria,idcompania,imagen) values('Leche light envase tetra brick',9.5,345,1,1,1,'15.jpg');
insert into productos (fullnombre,precio,cantidad,idnombreprod,idcategoria,idcompania,imagen) values('Leche deslactosada envase brick',8.75,239,1,1,1,'16.jpg');
insert into productos (fullnombre,precio,cantidad,idnombreprod,idcategoria,idcompania,imagen) values('Leche chocolatada envase brick',9.5,346,1,1,1,'17.jpg');
insert into productos (fullnombre,precio,cantidad,idnombreprod,idcategoria,idcompania,imagen) values('Leche saboridaza vainilla',9,363,1,1,1,'18.jpg');
insert into productos (fullnombre,precio,cantidad,idnombreprod,idcategoria,idcompania,imagen) values('Leche blanca cremosa',7.50,573,1,1,1,'19.jpg');
insert into productos (fullnombre,precio,cantidad,idnombreprod,idcategoria,idcompania,imagen) values('Leche blanca Pura Vida',5.50,512,1,1,1,'20.jpg');
insert into productos (fullnombre,precio,cantidad,idnombreprod,idcategoria,idcompania,imagen) values('Leche enriquecida Pura Vida',6.50,345,1,1,1,'21.jpg');
insert into productos (fullnombre,precio,cantidad,idnombreprod,idcategoria,idcompania,imagen) values('Leche Pil para niños',5.50,436,1,1,1,'22.jpg');
insert into productos (fullnombre,precio,cantidad,idnombreprod,idcategoria,idcompania,imagen) values('Leche de soya Multilac',5.00,435,1,1,1,'25.jpg');



create table carrito(
	id int identity not null primary key,
	idusuario int not null,
	idproducto int not null,
	cantidad int not null default 0,
	foreign key(idproducto) references productos(id)
	on delete cascade
	on update cascade,
	foreign key(idusuario) references usuario(id)
	on delete cascade
	on update cascade
);

insert into carrito(idusuario,idproducto,cantidad) values('21','2','1');

UPDATE `carrito` SET `cantidad` = '2' WHERE `carrito`.`id` = 1;

alter table productos add descuento decimal(3,2) default 0.00




;-----------------------------------------
create table admin(
	id int identity primary key,
	nombre varchar(16),
	apellidos varchar(64),
	correo varchar(64),
	contra varchar(64)
);

insert into admin(nombre,apellidos,correo,contra) values('christian','torrico avila','admin@biensurtido.com','$2y$10$y4tddCge9HiKZDWFPBhX7uwSM5Nr3bcoo7TTIjxyBOGEZIEas7z0C');


;-----

create table empleados(
	id int identity primary key,
	nombre varchar (16) not null,
	apellidos varchar(64) not null,
	ocupacion varchar(64) not null
);

create table ventas(
	id int identity not null primary key,
	idusuario int not null,
	idproducto int not null,
	cantidad int not null default 0,
	foreign key(idproducto) references productos(id)
	on delete cascade
	on update cascade,
	foreign key(idusuario) references usuario(id)
	on delete cascade
	on update cascade
);











